#include <cmath>
#include "sfs.hpp"
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>

#ifndef NDEBUG
#include <opencv2/highgui.hpp>
#endif

namespace fsiv
{

#ifndef NDEBUG
int DebugLevel_=0;
#endif

cv::Mat
Voxel::center() const
{
    cv::Mat center;
    //TODO

    //
    CV_Assert(center.rows=3 && center.cols==1 && center.type()==CV_32FC1);
    return center;

}

cv::Mat Voxel::vertices() const
{
    cv::Mat ret = cv::Mat::zeros(3, 8, CV_32FC1);
    //TODO

    //
    CV_Assert(ret.type()==CV_32FC1 && ret.rows==3 && ret.cols==8);
    return ret;
}


void
VoxelSet::reset(const Voxel& bc, const float vsize,
                const bool init_occ_state)
{
    //TODO    


    //
    CV_Assert(size() == x_size()*y_size()*z_size());
    CV_Assert(_occupancy_map.type()==CV_8UC1);
    CV_Assert(_occupancy_map.rows==1 && _occupancy_map.cols==size());
}

size_t
VoxelSet::xyz2index (const size_t x, const size_t y, const size_t z) const
{
  CV_Assert (x<x_size() && y<y_size() && z<z_size());
  size_t idx = 0;
  //TODO

  //
  CV_Assert(idx<size());
  return idx;
}

void
VoxelSet::index2xyz (const size_t index, size_t& x, size_t& y, size_t& z) const
{
  CV_Assert(index < size());
  //TODO


  //
  CV_Assert(x<x_size());
  CV_Assert(y<y_size());
  CV_Assert(z<z_size());
}


bool
VoxelSet::is_external(const size_t x, const size_t y, const size_t z) const
{
    CV_Assert (x<x_size() && y<y_size() && z<z_size());
    bool is_external = false;
    //TODO
    //Remenber: A voxel is considered external if it is in the limits
    //of the voxelset or any of its neighbors voxels is not occupied.


    //
    return is_external;
}



cv::Mat
CameraParameters::rotation_matrix () const
{
    cv::Mat rotmat;
    //TODO
    //Hint: use the cv::Rodrigues function.
    cv::Rodrigues(_rotation_vector, rotmat);
    //
    CV_Assert(rotmat.rows==3 && rotmat.cols==3);
    return rotmat;
}

View::View(const std::string id, const cv::Mat& fg_img, const CameraParameters& cparams)
{
    CV_Assert(fg_img.type()==CV_8UC1);
    _id = id;
    _foreground = fg_img;
    _cparams = cparams;
    //TODO
    //Compute the integral image from _fg_img.
    //First: we need use the fg_img with values 0|1.
    //Second: use cv::integral.


    //
    CV_Assert(iimg().type()==CV_32S);
}

cv::Mat View::project_points(const cv::Mat &_3dPoints) const
{
    cv::Mat _2dPoints;
    //TODO
    //Hint: use the cv::projectPoints() function.
    cv::projectPoints(_3dPoints, _cparams.rotation_vector(),
                      _cparams.translation_vector(),
                      _cparams.camera_matrix(),
                      _cparams.distortion_coeffs(),
                      _2dPoints);
    //
    CV_Assert(_2dPoints.channels()==2);
    return _2dPoints;
}
cv::Rect
View::compute_bounding_box(const cv::Mat& _3dPoints) const
{
    cv::Rect bbox;
    //TODO
    //Remenber: Find the bounding box that circumscribes the projections of the
    //3D points in the image plane.
    //The bounding box must be clipped using regarding image dimensions.
    //For that, use the overloaded operator '&' for the cv::Rect class.


    //
    return bbox;
}

int
View::compute_occupied_area(const cv::Rect& bbox) const
{
  CV_Assert (bbox.area()>=0);
  int area = 0;
  //TODO
  //Hint: use the integral image of the foreground to do this with O(1).
  //See documentation of cv::integral



  //
  return area;
}

static bool
voxelset_projection_test(const Voxel& voxel, std::vector<View> const& views,
                         const float OAR_th)
{
    bool is_occupied = true;
    //TODO:
    //Remember: for each view test if the projected bbox has enough foreground area.
    //Not take into account a view if the projection is out of the image frame (bbox.area()==0).


    //
    return is_occupied;
}

void
compute_visual_hull(std::vector<View> const& views, VoxelSet& vs,
                    const Voxel& scene, float vsize, const float OAR_th)
{
    vs.reset(scene, vsize);
    //TODO
    //Apply the SFS algorithm.    
    //Do a projection test for each voxel.
    //Hint: use "#pragma omp parallel for" to parallelize the loop.    
#pragma omp parallel for
    for (size_t voxel_idx=0; voxel_idx<vs.size(); ++voxel_idx)
    {        
        bool is_occupied = voxelset_projection_test(vs.voxel(voxel_idx),
                                                    views, OAR_th);
        vs.set_occupancy(voxel_idx, is_occupied);
    }
    //
}

static OctantState
octree_projection_test(const Voxel& voxel, std::vector<View> const& views,
                       const size_t level, const size_t max_levels,
                       const size_t max_errors, const float OAR_th)
{
    OctantState st = BLACK;
    //TODO
    //Aply the Projection Test for each view.
    //Remeber: the inner nodes have three states:
    //       WHITE (OAR==0 && errors<max_errors),
    //           GREY((OAR==0 && errors<max_errors)||0<OAR<1), BLACK(OAR==1).
    //while leaf nodes (at the last level) only have two states:
    //       WHITE (OAR<OAR_th), BLACK(OAR>=OAR_th).

    //
    return st;
}

static void
process_octant(Octant& oct, std::vector<View> const& views,
                const size_t level, const size_t max_levels,
               const size_t max_errors, const float OAR_th)
{
    //TODO
    //Apply the SFS algorithm on this octant.
    //First compute the its state using the projection test.
    //Second if the state is GREY, split and do recursion to go down in the tree.
    //Remenber to actualize level var in the recursion.



    //
}

void
compute_visual_hull(std::vector<View> const& views, Octree& octree,
                    const Voxel &scene, size_t max_levels,
                    size_t max_errors, const float OAR_th)
{
    CV_Assert(max_errors<=views.size());
    //TODO
    //Apply the SFS algorithm.
    //First, Create a root octant and processed.
    //Second, set the octant as the root node of the octree.



    //
}

} //namespace fsiv
