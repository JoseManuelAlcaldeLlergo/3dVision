José Manuel Alcalde Llergo

Project image
Con ejes
./aug_real 5 6 0.04 ../data/logitech.xml ../data/logitech_000_000.png -i=../data/computer-vision.jpg
Con modelo
./aug_real 5 6 0.04 ../data/logitech.xml ../data/logitech_000_003.png -i=../data/computer-vision.jpg -m

Project video
Con ejes
./aug_real 5 6 0.04 ../data/logitech.xml ../data/logitech_000_001.png -v=../data/tablero_000_000.avi
Con modelo
./aug_real 5 6 0.04 ../data/logitech.xml ../data/logitech_000_001.png -v=../data/tablero_000_000.avi -m