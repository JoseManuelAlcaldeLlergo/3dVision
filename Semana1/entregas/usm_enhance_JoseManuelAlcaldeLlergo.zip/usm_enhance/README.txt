José Manuel Alcalde Llergo

Mejorar interactividad, tratar de quitar las variables globales
