José Manuel Alcalde Llergo

GRAY
./usm_enhance -r=7 -f=1 ../Data/radiografia.png out.jpg

Color
./usm_enhance -r=7 -f=1 ../Data/ciclista_original.jpg out.jpg

Interactivo
./usm_enhance -r=7 -f=1 ../Data/radiografia.png out.jpg -i
./usm_enhance -f=1 ../Data/ciclista_original.jpg outi.jpg -i
