José Manuel Alcalde Llergo.

./esqueleto ../data/ciclista_original.jpg 
./esqueleto ../data/rojo.jpg