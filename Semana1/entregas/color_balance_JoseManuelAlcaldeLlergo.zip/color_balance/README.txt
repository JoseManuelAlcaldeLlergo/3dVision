José Manuel Alcalde Llergo

./color_balance ../Data/manos_original.jpg salida.jpg

./color_balance -p=10 ../Data/manos_original.jpg salida.jpg

Modo interactivo
../color_balance -i ../Data/manos_original.jpg salida.jpg