José Manuel Alcalde Llergo

GRAY
./img_equalization ../data/radiografia.png out.png
./img_equalization ../data/radiografia.png out.png -r=25

Color canal V
./img_equalization ../data/cells.png outcolor.png -r=10