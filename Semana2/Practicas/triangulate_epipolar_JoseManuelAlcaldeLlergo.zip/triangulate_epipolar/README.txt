Ejecución:
./triangulate_epipolar ../cam0/00-center.jpg ../cam0/01-right.jpg ../cam0/calibration.yml my_out.pcd