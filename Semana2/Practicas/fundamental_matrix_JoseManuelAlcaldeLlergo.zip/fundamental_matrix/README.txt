Ejecución:

./fundamental_matrix ../cam0/00-center.jpg ../cam0/01-right.jpg ../cam0/calibration.yml
